from flask import Flask, render_template, request, redirect, send_file, flash
import sqlite3
import io
from datetime import datetime
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet

app = Flask(__name__)
app.secret_key = 'chave_secreta'

# =========================
# BANCO DE DADOS
# =========================

def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS alunos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        altura REAL,
        data_nascimento TEXT,
        peso REAL,
        serie TEXT)
        """)
    
    conn.commit()
    conn.close()

init_db()

# =========================
# FUNÇÃO DE ERRO
# =========================

def retornar_erro(mensagem):
    flash(mensagem, "erro")  
    return redirect("/")

# =========================
# PÁGINA PRINCIPAL
# =========================

@app.route('/')
def index():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute("""SELECT * FROM alunos
    ORDER BY 
    CAST(SUBSTR(serie, 1, LENGTH(serie)-1) AS INTEGER),
    SUBSTR(serie, -1),
    nome""")
    alunos_db = cursor.fetchall()
    
    alunos = []
    hoje = datetime.today()

    total_altura = 0
    total_peso = 0

    imc_normal = 0
    imc_sobrepeso = 0
    imc_obesidade = 0

    for aluno in alunos_db:
        nascimento = datetime.strptime(aluno[3], "%Y-%m-%d")

        idade = hoje.year - nascimento.year - (
            (hoje.month, hoje.day) < (nascimento.month, nascimento.day))

        imc = aluno[4] / (aluno[2] ** 2)

        total_altura += aluno[2]
        total_peso += aluno[4]

        if imc < 25:
            imc_normal += 1
        elif imc < 30:
            imc_sobrepeso += 1
        else:
            imc_obesidade += 1

        alunos.append({
            "id": aluno[0],
            "nome": aluno[1],
            "altura": aluno[2],
            "data": aluno[3],
            "peso": aluno[4],
            "serie": aluno[5],
            "idade": idade,
            "imc": round(imc, 2)
        })

    total = len(alunos_db)

    media_altura = round(total_altura / total, 2) if total > 0 else 0
    media_peso = round(total_peso / total, 2) if total > 0 else 0

    conn.close()

    return render_template(
        'index.html',
        alunos=alunos,
        media_altura=media_altura,
        media_peso=media_peso,
        imc_normal=imc_normal,
        imc_sobrepeso=imc_sobrepeso,
        imc_obesidade=imc_obesidade
    )

# =========================
# CADASTRAR ALUNO
# =========================

@app.route('/add', methods=['POST'])
def add():
    nome = request.form['nome']
    altura = request.form['altura']
    peso = request.form['peso']
    data_nascimento = request.form['data_nascimento']
    serie = request.form['serie']

    if not nome.strip():
        return retornar_erro("Nome é obrigatório.")

    try:
        altura = float(altura.replace(',', '.'))
        if altura <= 0:
            return retornar_erro("Altura inválida.")
    except:
        return retornar_erro("Altura deve ser um número.")

    try:
        peso = float(peso.replace(',', '.'))
        if peso <= 0:
            return retornar_erro("Peso inválido.")
    except:
        return retornar_erro("Peso deve ser um número.")

    if not data_nascimento:
        return retornar_erro("Data de nascimento é obrigatória.")

    try:
        datetime.strptime(data_nascimento, "%Y-%m-%d")
    except ValueError:
        return retornar_erro("Data inválida. Use o formato correto (AAAA-MM-DD).")

    if not serie.strip():
        return retornar_erro("Série é obrigatória.")

    # =========================
    # BANCO DE DADOS
    # =========================

    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO alunos (nome, altura, data_nascimento, peso, serie)
            VALUES (?, ?, ?, ?, ?)
        """, (nome, altura, data_nascimento, peso, serie))

        conn.commit()
        conn.close()

    except Exception as e:
        return retornar_erro("Erro ao salvar no banco de dados.")

    flash("Aluno cadastrado com sucesso!", "sucesso")

    return redirect('/')
    

# =========================
# EXCLUIR CADASTRO
# =========================

@app.route('/delete/<int:id>')
def delete(id):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute("DELETE FROM alunos WHERE id = ?", (id,))
    
    conn.commit()
    conn.close()
    
    flash("Aluno removido com sucesso!", "erro")
    return redirect('/')

# =========================
# GERAR PDF
# =========================

@app.route('/pdf')
def gerar_pdf():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM alunos")
    alunos = cursor.fetchall()
    conn.close()

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []

    styles = getSampleStyleSheet()
    titulo = Paragraph("Lista de Alunos", styles['Title'])
    elements.append(titulo)

    dados = [["Nome", "Idade", "Altura (m)", "Peso (kg)", "IMC", "Série"]]

    hoje = datetime.today()

    for aluno in alunos:
        nascimento = datetime.strptime(aluno[3], "%Y-%m-%d")

        idade = hoje.year - nascimento.year - (
            (hoje.month, hoje.day) < (nascimento.month, nascimento.day)
        )

        imc = aluno[4] / (aluno[2] ** 2)

        dados.append([
            aluno[1],
            idade,
            f"{aluno[2]:.2f}".replace('.', ','),
            f"{aluno[4]:.2f}".replace('.', ','),
            f"{imc:.2f}".replace('.', ','),
            aluno[5]
        ])

    tabela = Table(dados)

    tabela.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
        ('BACKGROUND', (0, 1), (-1, -1), colors.whitesmoke),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ]))

    elements.append(tabela)

    doc.build(elements)
    buffer.seek(0)

    return send_file(buffer, as_attachment=True, download_name="alunos.pdf", mimetype='application/pdf')

# =========================
# EDITAR CADASTRO
# =========================

@app.route('/edit/<int:id>')
def edit(id):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM alunos WHERE id = ?", (id,))
    aluno = cursor.fetchone()

    conn.close()

    return render_template('edit.html', aluno=aluno)

@app.route('/update/<int:id>', methods=['POST'])
def update(id):
    nome = request.form['nome']
    altura = request.form['altura']
    peso = request.form['peso']
    data_nascimento = request.form['data_nascimento']
    serie = request.form['serie']

    try:
        altura = float(altura.replace(',', '.'))
        peso = float(peso.replace(',', '.'))
    except:
        return redirect('/')
    
    try:
        datetime.strptime(data_nascimento, "%Y-%m-%d")
    except ValueError:
        return retornar_erro("Data inválida. Use o formato correto (AAAA-MM-DD).")

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE alunos
        SET nome = ?, altura = ?, data_nascimento = ?, peso = ?, serie = ?
        WHERE id = ?
    """, (nome, altura, data_nascimento, peso, serie, id))

    conn.commit()
    conn.close()

    flash("Aluno atualizado com sucesso!", "sucesso")
    return redirect('/')

# =========================
# RODAR APP
# =========================

if __name__ == '__main__':
    app.run(host='192.168.1.10', port=5000, debug=True)

# =========================
# Desenvolvido por Jheymes
# =========================