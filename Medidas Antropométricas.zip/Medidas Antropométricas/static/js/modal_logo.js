const logo = document.getElementById("logoClick");
const modal = document.getElementById("modalLogo");

logo.addEventListener("click", () => {
    modal.style.display = "flex";
    setTimeout(() => modal.classList.add("show"), 10);
});

modal.addEventListener("click", () => {
    modal.classList.remove("show");
    setTimeout(() => modal.style.display = "none", 200);
});