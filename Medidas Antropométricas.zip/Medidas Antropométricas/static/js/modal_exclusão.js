let alunoId = null;

function abrirModal(id) {
    alunoId = id;
    document.getElementById("modalConfirm").style.display = "flex";
}

function fecharModal() {
    document.getElementById("modalConfirm").style.display = "none";
}

function confirmarExclusao() {
    window.location.href = "/delete/" + alunoId;
}