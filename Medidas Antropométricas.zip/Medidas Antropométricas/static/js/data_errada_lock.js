document.querySelector("form").addEventListener("submit", function(e) {
    const data = document.querySelector("input[name='data_nascimento']").value;

    if (!data) return;

    const partes = data.split("-");
    const ano = parseInt(partes[0]);
    const mes = parseInt(partes[1]);
    const dia = parseInt(partes[2]);

    const dataObj = new Date(ano, mes - 1, dia);

    if (
        dataObj.getFullYear() !== ano ||
        dataObj.getMonth() !== mes - 1 ||
        dataObj.getDate() !== dia
    ) {
        alert("Data inválida!");
        e.preventDefault();
    }
});