function buscarAluno() {
    let input = document.getElementById("busca").value.toLowerCase();
    let linhas = document.querySelectorAll("table tr");

    linhas.forEach((linha, index) => {
        if (index === 0) return;

        let texto = linha.innerText.toLowerCase();
        linha.style.display = texto.includes(input) ? "" : "none";
    });
}